import tkinter as tk
from tkinter import messagebox

# Function to encrypt Caesar cipher
def caesar_encrypt(text, shift):
    encrypted_text = ""
    for char in text:
        if char.isalpha():
            shift_base = 65 if char.isupper() else 97
            encrypted_text += chr((ord(char) - shift_base + shift) % 26 + shift_base)
        else:
            encrypted_text += char
    return encrypted_text

# Function to decrypt Caesar cipher
def caesar_decrypt(text, shift):
    decrypted_text = ""
    for char in text:
        if char.isalpha():
            shift_base = 65 if char.isupper() else 97
            decrypted_text += chr((ord(char) - shift_base - shift) % 26 + shift_base)
        else:
            decrypted_text += char
    return decrypted_text

# Function to encrypt the input text
def encrypt_text():
    try:
        text = input_text.get("1.0", "end-1c")
        shift = int(shift_value.get())
        encrypted_text = caesar_encrypt(text, shift)
        result_text.config(state="normal")
        result_text.delete("1.0", "end")
        result_text.insert("1.0", encrypted_text)
        result_text.config(state="disabled")
    except ValueError:
        messagebox.showerror("Error", "Please enter a valid shift value.")

# Function to decrypt the input text
def decrypt_text():
    try:
        text = input_text.get("1.0", "end-1c")
        shift = int(shift_value.get())
        decrypted_text = caesar_decrypt(text, shift)
        result_text.config(state="normal")
        result_text.delete("1.0", "end")
        result_text.insert("1.0", decrypted_text)
        result_text.config(state="disabled")
    except ValueError:
        messagebox.showerror("Error", "Please enter a valid shift value.")

# Function to clear all fields
def clear_all():
    input_text.delete("1.0", "end")
    result_text.config(state="normal")
    result_text.delete("1.0", "end")
    result_text.config(state="disabled")
    shift_value.delete(0, "end")

# User Interface
root = tk.Tk()
root.title("Caesar Cipher Encryption and Decryption")

# Input Text
tk.Label(root, text="Enter Text:").pack(pady=5)
input_text = tk.Text(root, height=5, width=50)
input_text.pack(pady=5)

# Shift Value
tk.Label(root, text="Shift Value:").pack(pady=5)
shift_value = tk.Entry(root, width=10)
shift_value.pack(pady=5)

# Encrypt Button
encrypt_button = tk.Button(root, text="Encrypt", command=encrypt_text)
encrypt_button.pack(pady=5)

# Decrypt Button
decrypt_button = tk.Button(root, text="Decrypt", command=decrypt_text)
decrypt_button.pack(pady=5)

# Result Text
tk.Label(root, text="Result:").pack(pady=5)
result_text = tk.Text(root, height=5, width=50, state="disabled")
result_text.pack(pady=5)

# Clear Button
clear_button = tk.Button(root, text="Clear", command=clear_all)
clear_button.pack(pady=5)

# Run the application
root.mainloop()
